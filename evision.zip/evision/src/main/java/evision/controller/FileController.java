package evision.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import evision.dto.File;
import evision.service.FileService;

@RestController
public class FileController {
	@Autowired
	private FileService fileService;

	@GetMapping("/compare")
	public List<File> compareFiles() throws IOException {
		return fileService.compareFiles();
	}
}
