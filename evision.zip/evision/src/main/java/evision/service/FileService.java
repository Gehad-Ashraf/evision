package evision.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import evision.dto.File;

@Service
public class FileService {

	@Value("${fileA.path}")
	private String fileAPath;
	@Value("${pool.dir}")
	private String poolDirectory;

	public List<File> compareFiles() throws IOException {
		Set<String> fileAWords = extractWordsFromFile(fileAPath);
		List<File> fileScores = new ArrayList<>();
		Path path = Paths.get(poolDirectory);
		try (Stream<Path> paths = Files.walk(path)) {
			paths.filter(Files::isRegularFile).forEach(filePath -> {
				try {
					Set<String> poolFileWords = extractWordsFromFile(filePath.toString());
					long count = fileAWords.stream().filter(poolFileWords::contains).count();
					double score = ((double) count / fileAWords.size()) * 100;
					fileScores.add(new File(filePath.getFileName().toString(), score));
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
		}
		return fileScores;
	}

	private Set<String> extractWordsFromFile(String filePath) throws IOException {
		Set<String> words = new HashSet<>();

		try (

				Stream<String> lines = Files.lines(Paths.get(filePath))) {
			lines.forEach(line -> {
				String[] lineWords = line.split("\\W+");
				for (String word : lineWords) {
					if (word.matches("[a-zA-Z]+")) {
						words.add(word);
					}
				}
			});
		}
		return words;
	}

}
